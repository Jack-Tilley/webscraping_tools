=================
webscraping_tools
=================


.. image:: https://img.shields.io/pypi/v/webscraping_tools.svg
        :target: https://pypi.python.org/pypi/webscraping_tools

.. image:: https://img.shields.io/travis/Jack-Tilley/webscraping_tools.svg
        :target: https://travis-ci.org/Jack-Tilley/webscraping_tools

.. image:: https://readthedocs.org/projects/webscraping-tools/badge/?version=latest
        :target: https://webscraping-tools.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Tools to make webscraping easier.


* Free software: MIT license
* Documentation: https://webscraping-tools.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
