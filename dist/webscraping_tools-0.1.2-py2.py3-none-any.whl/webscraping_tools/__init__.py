# -*- coding: utf-8 -*-

"""Top-level package for webscraping_tools."""

__author__ = """Jack Tilley"""
__email__ = 'tilley.e.jack@gmail.com'
__version__ = '0.1.0'
