#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""Tests for `webscraping_tools` package."""


import unittest

from webscraping_tools import webscraping_tools


class TestWebscraping_tools(unittest.TestCase):
    """Tests for `webscraping_tools` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
