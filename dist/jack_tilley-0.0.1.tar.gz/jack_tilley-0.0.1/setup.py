import setuptools
with open("README.md", "r") as fh:
    long_description = fh.read()
setuptools.setup(
     name='jack_tilley',  
     version='0.0.1',
     author="Jack Tilley",
     author_email="tilley.e.jack@gmail.com",
     description="Tools to make webscraping easier.",
     long_description=long_description,
   long_description_content_type="text/markdown",
     url="https://github.com/Jack-Tilley/webscraping-tools",
     packages=setuptools.find_packages(),
     classifiers=[
         "Programming Language :: Python :: 3",
         "License :: OSI Approved :: MIT License",
         "Operating System :: OS Independent",
     ],
 )
